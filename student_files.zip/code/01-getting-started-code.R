# Getting Started with R
# EDUS 664 - Multilevel Modeling
# Reference version. Complete code from the chapter.
#
# Keep this file in the same folder as the data file named at the
# top of the chapter, or the read_ lines below will not find it.
# Generated from 01-getting-started.qmd on 2026-08-15 - do not edit by hand.


##########################################################################
## GETTING STARTED WITH R
##########################################################################

# Data file needed ----------------------------------------------------

# Packages ------------------------------------------------------------

# (not run in the book - shown for reference)
# 
# install.packages(c("tidyverse", "haven", "psych"))

# [setup]

library(tidyverse)
library(haven)
library(psych)

# Reading data in -----------------------------------------------------

hsb2 <- read_dta("hsb2.dta")

# First look ----------------------------------------------------------

glimpse(hsb2)

describe(hsb2)

# The first real trap: categorical variables stored as numbers --------

table(hsb2$prog)

# As proportions
prop.table(table(hsb2$prog))

str(hsb2$prog)

hsb2 <- hsb2 |>
  mutate(
    prog_f   = factor(prog, levels = c(1, 2, 3),
                      labels = c("General", "Academic", "Vocational")),
    ses_f    = factor(ses, levels = c(1, 2, 3),
                      labels = c("Low", "Middle", "High")),
    female_f = factor(female, levels = c(0, 1),
                      labels = c("Male", "Female")),
    schtyp_f = factor(schtyp, levels = c(1, 2),
                      labels = c("Public", "Private"))
  )

table(hsb2$prog_f)
table(hsb2$ses_f)

# A shortcut for Stata files ------------------------------------------

# The pipe ------------------------------------------------------------

# (not run in the book - shown for reference)
# 
# describe(hsb2$write)
# hsb2$write |> describe()

hsb2 |>
  group_by(ses_f) |>
  summarize(
    n = n(),
    mean_write = mean(write, na.rm = TRUE),
    sd_write = sd(write, na.rm = TRUE)
  )

# Graphics ------------------------------------------------------------

# [fig-basehist]

hist(hsb2$write,
     main = "Distribution of Writing Scores",
     xlab = "Standardized writing score")

# [fig-ggplot]

ggplot(hsb2, aes(x = write)) +
  geom_histogram(bins = 20, fill = "#1a7a6e", color = "white") +
  labs(
    title = "Distribution of Writing Scores",
    x = "Standardized writing score",
    y = "Number of students"
  ) +
  theme_minimal()

## Comparing groups, and why the axis scale matters

# [fig-filtered]

low    <- hsb2 |> filter(ses == 1)
middle <- hsb2 |> filter(ses == 2)
high   <- hsb2 |> filter(ses == 3)

par(mfrow = c(1, 3))
hist(low$write,    main = "Low SES",    xlab = "Writing score")
hist(middle$write, main = "Middle SES", xlab = "Writing score")
hist(high$write,   main = "High SES",   xlab = "Writing score")
par(mfrow = c(1, 1))

# [fig-facet]

ggplot(hsb2, aes(x = write)) +
  geom_histogram(bins = 20, fill = "#1a7a6e", color = "white") +
  facet_wrap(~ses_f) +
  labs(
    title = "Writing Scores by Socioeconomic Status",
    x = "Standardized writing score",
    y = "Number of students"
  ) +
  theme_minimal()

# [fig-box]

ggplot(hsb2, aes(x = ses_f, y = write, fill = ses_f)) +
  geom_boxplot(alpha = 0.7) +
  scale_fill_manual(values = c("#e0f2ef", "#8cc9c0", "#1a7a6e")) +
  labs(
    title = "Writing Scores by Socioeconomic Status",
    x = NULL, y = "Standardized writing score"
  ) +
  theme_minimal() +
  theme(legend.position = "none")

# Where to go when something breaks -----------------------------------

