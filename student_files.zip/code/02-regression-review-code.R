# Review of Regression
# EDUS 664 - Multilevel Modeling
# Reference version. Complete code from the chapter.
#
# Keep this file in the same folder as the data file named at the
# top of the chapter, or the read_ lines below will not find it.
# Generated from 02-regression-review.qmd on 2026-08-15 - do not edit by hand.


##########################################################################
## REVIEW OF REGRESSION
##########################################################################

# Data file needed ----------------------------------------------------

# [setup]

library(tidyverse)
library(haven)
library(psych)
library(modelsummary)

nlsw <- read_dta("nlsw88.dta")

glimpse(nlsw)

# Preparing the variables ---------------------------------------------

nlsw <- nlsw |>
  mutate(
    collgrad_f = factor(collgrad, levels = c(0, 1),
                        labels = c("Not college grad", "College grad")),
    race_f     = factor(race, levels = c(1, 2, 3),
                        labels = c("White", "Black", "Other")),
    union_f    = factor(union, levels = c(0, 1),
                        labels = c("Non-union", "Union"))
  )

table(nlsw$collgrad_f)
table(nlsw$race_f)

## A note on missing data

nlsw |>
  summarize(across(c(wage, age, ttl_exp, collgrad, union, hours, industry),
                   ~ sum(is.na(.)))) |>
  pivot_longer(everything(), names_to = "variable", values_to = "n_missing")

# A single predictor --------------------------------------------------

describe(nlsw$wage)

# [fig-wage]

ggplot(nlsw, aes(x = wage)) +
  geom_histogram(bins = 40, fill = "#1a7a6e", color = "white") +
  labs(title = "Distribution of Hourly Wages",
       x = "Hourly wage (1988 dollars)", y = "Number of women") +
  theme_minimal()

m1 <- lm(wage ~ ttl_exp, data = nlsw)

summary(m1)

# Building up a series of models --------------------------------------

m2 <- lm(wage ~ ttl_exp + age, data = nlsw)
m3 <- lm(wage ~ ttl_exp + age + collgrad_f, data = nlsw)

summary(m3)

# An interaction ------------------------------------------------------

m4 <- lm(wage ~ ttl_exp * age + collgrad_f, data = nlsw)

summary(m4)

nlsw <- nlsw |>
  mutate(
    age_c     = age - mean(age, na.rm = TRUE),
    ttl_exp_c = ttl_exp - mean(ttl_exp, na.rm = TRUE)
  )

m5 <- lm(wage ~ ttl_exp_c * age_c + collgrad_f, data = nlsw)

summary(m5)

# [fig-interaction]

library(ggeffects)

plot(ggpredict(m5, terms = c("ttl_exp_c", "age_c [-5, 0, 5]")))

# Comparing the models ------------------------------------------------

modelsummary(
  list("M1" = m1, "M2" = m2, "M3" = m3, "M4: Interaction" = m4),
  stars = c("*" = .05, "**" = .01, "***" = .001),
  gof_map = c("nobs", "r.squared", "adj.r.squared", "aic", "bic"),
  title = "OLS models predicting hourly wages"
)

# Checking assumptions ------------------------------------------------

# [fig-diagnostics]

par(mfrow = c(2, 2))
plot(m3)
par(mfrow = c(1, 1))

# Where this breaks ---------------------------------------------------

nlsw |>
  filter(!is.na(industry)) |>
  count(industry, name = "n_women") |>
  arrange(desc(n_women)) |>
  head(10)

industry_summary <- nlsw |>
  filter(!is.na(industry), !is.na(wage)) |>
  group_by(industry) |>
  summarize(
    n_women = n(),
    mean_wage = mean(wage),
    .groups = "drop"
  ) |>
  filter(n_women >= 20)

industry_summary |> arrange(desc(mean_wage))

# [fig-industry]

ggplot(industry_summary, aes(x = reorder(factor(industry), mean_wage), y = mean_wage)) +
  geom_col(fill = "#1a7a6e") +
  coord_flip() +
  labs(title = "Mean Hourly Wage by Industry",
       subtitle = "Industries with at least 20 respondents",
       x = "Industry code", y = "Mean hourly wage") +
  theme_minimal()

