# Review of Linear Regression
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 02-regression-review.qmd on 2026-08-21 - do not edit by hand.

# Reference version: complete code from the chapter.


##########################################################################
## REVIEW OF LINEAR REGRESSION
##########################################################################

# Data file needed ------------------------------------------------------

# Load a few packages ---------------------------------------------------

# [setup]

library(tidyverse)
library(ggplot2)
library(broom)
library(skimr)

# Input the food dataset ------------------------------------------------

food <- read_csv("food.csv")

glimpse(food)

# Data cleaning and coding ----------------------------------------------

food.clean <- food %>%
  rename(.,
         food_consumption = FOODCONSUMPTION,
         family_income = FAMILYINCOME,
         num_children = NUMCHULDREN,
         have_garden = HAVEGARDEN) %>%
  mutate(.,
         have_garden_fac = as_factor(have_garden)) %>%
  na.omit()

glimpse(food.clean)

# How many observations did we actually lose?
nrow(food); nrow(food.clean)

# Use `skim` for a nice summary -----------------------------------------

skim(food.clean)

# A simple linear regression: does income predict food consumption? -----

foodreg1 <- lm(food_consumption ~ family_income, data = food.clean)

summary(foodreg1)

# What about kids? Do things change when we account for them? -----------

foodreg2 <- lm(food_consumption ~ family_income + num_children, data = food.clean)

summary(foodreg2)

# Now, what about families who have a garden? ---------------------------

foodreg3 <- lm(food_consumption ~ family_income + num_children + have_garden_fac,
               data = food.clean)

summary(foodreg3)

# Does the number of children moderate the income-food relationship? ----

foodreg4 <- lm(food_consumption ~ family_income + num_children +
                 family_income:num_children,
               data = food.clean)

summary(foodreg4)

# Organizing your results -----------------------------------------------

library(modelsummary)

models <- list(
  "Income"        = foodreg1,
  "+ Children"    = foodreg2,
  "+ Garden"      = foodreg3,
  "Interaction"   = foodreg4
)

modelsummary(
  models,
  stars = c("*" = .05, "**" = .01, "***" = .001),
  gof_map = c("nobs", "r.squared", "adj.r.squared"),
  fmt = 2,
  title = "Regression models predicting annual food expenditures"
)

# (not run in the book - shown for reference)
# 
# modelsummary(models, output = "food_models.docx",
#              stars = c("*" = .05, "**" = .01, "***" = .001))

# A note on `stargazer` -------------------------------------------------

# Where this goes next --------------------------------------------------

