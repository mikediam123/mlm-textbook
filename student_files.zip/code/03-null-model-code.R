# Intro to MLM and the Null Model
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 03-null-model.qmd on 2026-08-21 - do not edit by hand.

# Reference version: complete code from the chapter.


##########################################################################
## INTRO TO MLM AND THE NULL MODEL
##########################################################################

# Load some packages to help with the analysis and data management ------

# [setup]

library(tidyverse)
library(Hmisc)     # label()
library(lme4)
library(lmerTest)

# Package conflicts -----------------------------------------------------

# Load in the data and use `glimpse` to summarize the structure ---------

hsb <- read_csv("hsbmerged.csv")

glimpse(hsb)

# Quick data cleaning and coding tips -----------------------------------

## The `summary` command from base R is a quick and easy way to explore a new dataset

summary(hsb)

## Let's give some variables a label

label(hsb$mathach) = "Std. Math Score"
label(hsb$sector) = "School Sector"

str(hsb$sector)

## Let's create a factor version of `sector` and label its values

hsb.clean <- hsb %>%
  mutate(.,
         sector.factor = as_factor(sector),
         female.factor = as_factor(female),
         minority.factor = as_factor(minority))

levels(hsb.clean$sector.factor) = c("Public", "Parochial")
levels(hsb.clean$female.factor) = c("Male", "Female")
levels(hsb.clean$minority.factor) = c("Non-Minority", "Minority")

str(hsb.clean$sector.factor)

table(hsb.clean$sector.factor)

## Run `summary` again and notice how it handles factors

summary(hsb.clean)

# Exploring our outcome, math achievement -------------------------------

describe(hsb.clean$mathach)

# [fig-mathach]

hist(hsb.clean$mathach,
     main = "Distribution of Math Achievement Scores",
     sub = "N = 7,185. Students from the High School and Beyond Survey (1988).",
     xlab = "Standardized Math Achievement Score")

# [fig-schoolmeans]

school_means <- hsb.clean %>%
  group_by(schoolid) %>%
  dplyr::summarize(school_mean = mean(mathach, na.rm = TRUE))

hist(school_means$school_mean,
     main = "School Average Math Achievement",
     sub = "Each observation is one of 160 schools.",
     xlab = "School mean math achievement")

# Running a null model --------------------------------------------------

model.null <- lmer(mathach ~ (1|schoolid), REML = FALSE, data = hsb.clean)

summary(model.null)

# What makes `schoolid` a clustering variable, and what does not --------

# Why `REML = FALSE`? ---------------------------------------------------

# Post-estimation task: calculate the ICC -------------------------------

null.ICC <- 8.553/(8.553 + 39.148)
null.ICC

# Pulling the numbers out rather than typing them -----------------------

vc <- as.data.frame(VarCorr(model.null))

tau00  <- vc$vcov[vc$grp == "schoolid"]
sigma2 <- vc$vcov[vc$grp == "Residual"]

tau00 / (tau00 + sigma2)

# Using `lmerTest` to evaluate random effects ---------------------------

ranova(model.null)

# `rand()` became `ranova()` --------------------------------------------

# Always interesting: compare our MLM to a regular regression -----------

model.regular <- lm(mathach ~ NULL, data = hsb.clean)

summary(model.regular)

mean(hsb.clean$mathach, na.rm = TRUE)   # grand mean of all students
fixef(model.null)                       # model-based estimate

# What comes next -------------------------------------------------------

