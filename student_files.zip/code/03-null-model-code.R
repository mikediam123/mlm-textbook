# The Null Model
# EDUS 664 - Multilevel Modeling
# Reference version. Complete code from the chapter.
#
# Keep this file in the same folder as the data file named at the
# top of the chapter, or the read_ lines below will not find it.
# Generated from 03-null-model.qmd on 2026-08-15 - do not edit by hand.


##########################################################################
## THE NULL MODEL
##########################################################################

# Loading packages and data -------------------------------------------

# [setup]

library(tidyverse)
library(psych)
library(lme4)
library(lmerTest)
library(performance)

hsb <- read_csv("hsbmerged.csv")

glimpse(hsb)

# Looking at the data before modeling it ------------------------------

describe(hsb)

hsb <- hsb |>
  mutate(sector_f = factor(sector,
                           levels = c(0, 1),
                           labels = c("Public", "Catholic")))

table(hsb$sector_f)

# Exploring the outcome -----------------------------------------------

describe(hsb$mathach)

# [fig-mathach]

ggplot(hsb, aes(x = mathach)) +
  geom_histogram(bins = 30, fill = "#1a7a6e", color = "white") +
  labs(
    title = "Distribution of Math Achievement Scores",
    subtitle = "N = 7,185 students from the High School and Beyond Survey",
    x = "Standardized Math Achievement Score",
    y = "Number of students"
  ) +
  theme_minimal()

# [fig-schoolmeans]

hsb |>
  group_by(schoolid) |>
  summarize(school_mean = mean(mathach, na.rm = TRUE)) |>
  ggplot(aes(x = school_mean)) +
  geom_histogram(bins = 25, fill = "#1a7a6e", color = "white") +
  labs(
    title = "School Average Math Achievement",
    subtitle = "Each observation is one of 160 schools",
    x = "School mean math achievement",
    y = "Number of schools"
  ) +
  theme_minimal()

# Running a null model ------------------------------------------------

model_null <- lmer(mathach ~ 1 + (1 | schoolid), data = hsb, REML = FALSE)

summary(model_null)

# Why `REML = FALSE`? -------------------------------------------------

# Post-estimation: calculating the ICC --------------------------------

vc <- as.data.frame(VarCorr(model_null))

tau00 <- vc$vcov[vc$grp == "schoolid"]
sigma2 <- vc$vcov[vc$grp == "Residual"]

icc_by_hand <- tau00 / (tau00 + sigma2)
icc_by_hand

performance::icc(model_null)

# Is the clustering statistically detectable? -------------------------

ranova(model_null)

# Comparing to ordinary regression ------------------------------------

model_ols <- lm(mathach ~ 1, data = hsb)

summary(model_ols)

# Interpreting the fixed intercept ------------------------------------

# The grand mean of all students
mean(hsb$mathach, na.rm = TRUE)

# The model-based estimate
fixef(model_null)

# What comes next -----------------------------------------------------

