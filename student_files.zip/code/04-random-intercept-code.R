# Conditional Random Intercept Models
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 04-random-intercept.qmd on 2026-08-21 - do not edit by hand.

# Reference version: complete code from the chapter.


##########################################################################
## CONDITIONAL RANDOM INTERCEPT MODELS
##########################################################################

# Load some packages to help with the analysis and data management ------

# [setup]

library(tidyverse)
library(psych)
library(lme4)

# Load and explore the data ---------------------------------------------

lq2002 <- read_csv("lq2002.csv")

glimpse(lq2002)

psych::describe(lq2002,
                fast = TRUE)

# Calculating scale scores and Cronbach's alpha -------------------------

hostile_items <- lq2002 %>%
  select(., HOSTIL01,
         HOSTIL02,
         HOSTIL03,
         HOSTIL04,
         HOSTIL05)

alpha(hostile_items)

my.keys.list <- list(hostile = c("HOSTIL01","HOSTIL02","HOSTIL03", "HOSTIL04","HOSTIL05"))

my.scales <- scoreItems(my.keys.list, lq2002, impute = "none")

# Scale reliability estimates for Likert-type scales --------------------

print(my.scales, short = FALSE)

# Save scored scales as new variables -----------------------------------

my.scores <- as_tibble(my.scales$scores)

# Attach the new variable to the old dataset ----------------------------

lq2002.1 <- bind_cols(lq2002, my.scores)

glimpse(lq2002.1)

# Visualizing the key variables -----------------------------------------

# [fig-hostile]

hist(lq2002$HOSTILE,
     main = "Distribution of Hostility Scores",
     sub = "N = 2,042 U.S. Army active duty soliders. Data from Gavin and Hofmann (2002).",
     xlab = "Scaled Hostility Score")

# [fig-tsig]

hist(lq2002$TSIG,
     main = "Distribution of Task Significance Scores",
     sub = "N = 2,042 U.S. Army active duty soliders. Data from Gavin and Hofmann (2002).",
     xlab = "Scaled Task Significance Score")

# [fig-lead]

hist(lq2002$LEAD,
     main = "Distribution of Leadership Climate Scores",
     sub = "N = 2,042 U.S. Army active duty soliders. Data from Gavin and Hofmann (2002).",
     xlab = "Scaled Leadership Climate Score")

# Running the multilevel models -----------------------------------------

## Step one: the null model

model.0 <- lmer(HOSTILE ~ (1|COMPID), REML = FALSE, data = lq2002.1)

summary(model.0)

null.ICC <- 0.05765/(0.05765 + 1.01668)
null.ICC

lmerTest::rand(model.0)

# `rand()` and `ranova()` -----------------------------------------------

## Step two: adding a level-one predictor, `TSIG`

model.1 <- lmer(HOSTILE ~ TSIG + (1|COMPID), REML = FALSE, data = lq2002.1)

summary(model.1)

## Step three: adding an additional level-one predictor, `LEAD`

model.2 <- lmer(HOSTILE ~ TSIG + LEAD + (1|COMPID), REML = FALSE, data = lq2002.1)

summary(model.2)

## Step four: testing the interaction of `LEAD` and `TSIG`

model.3 <- lmer(HOSTILE ~ TSIG + LEAD + TSIG:LEAD + (1|COMPID), REML = FALSE, data = lq2002.1)

summary(model.3)

## Step five: adding a level-two predictor, `GTSIG`

model.4 <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG + (1|COMPID), REML = FALSE, data = lq2002.1)

summary(model.4)

## Step six: adding a second level-two predictor, `GLEAD`

model.5 <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG + GLEAD + (1|COMPID), REML = FALSE, data = lq2002.1)

summary(model.5)

# Should we include that interaction? Comparing `model.2` with `model.3` ----

anova(model.2, model.3)

# Using `modelsummary` and `broom.mixed` to organize your results -------

library(modelsummary)
library(broom.mixed)

models <- list(model.0, model.1, model.2, model.3, model.4, model.5)

modelsummary(models)

# HTML version that you can open in Word --------------------------------

# (not run in the book - shown for reference)
# 
# modelsummary(models, output = 'msum.html', title = 'MLM Estimates')

# What to take from this chapter ----------------------------------------

