# Conditional Random Intercept Models
# EDUS 664 - Multilevel Modeling
# Reference version. Complete code from the chapter.
#
# Keep this file in the same folder as the data file named at the
# top of the chapter, or the read_ lines below will not find it.
# Generated from 04-random-intercept.qmd on 2026-08-15 - do not edit by hand.


##########################################################################
## CONDITIONAL RANDOM INTERCEPT MODELS
##########################################################################

# [setup]

library(tidyverse)
library(psych)
library(lme4)
library(lmerTest)
library(performance)
library(modelsummary)

lq2002 <- read_csv("lq2002.csv")

glimpse(lq2002)

describe(lq2002)

# Building a scale score and checking reliability ---------------------

hostile_items <- lq2002 |>
  select(HOSTIL01, HOSTIL02, HOSTIL03, HOSTIL04, HOSTIL05)

psych::alpha(hostile_items)

keys <- list(hostile = c("HOSTIL01", "HOSTIL02", "HOSTIL03", "HOSTIL04", "HOSTIL05"))

scored <- psych::scoreItems(keys, lq2002, impute = "none")

lq2002 <- lq2002 |>
  mutate(hostile_mine = as.numeric(scored$scores[, "hostile"]))

# Does our version match the one in the file?
cor(lq2002$HOSTILE, lq2002$hostile_mine, use = "complete.obs")

# Looking at the key variables ----------------------------------------

# [fig-three-vars]

lq2002 |>
  select(HOSTILE, TSIG, LEAD) |>
  pivot_longer(everything(), names_to = "variable", values_to = "score") |>
  ggplot(aes(x = score)) +
  geom_histogram(bins = 25, fill = "#1a7a6e", color = "white") +
  facet_wrap(~variable, scales = "free_x") +
  labs(
    title = "Distributions of Hostility, Task Significance, and Leadership Climate",
    subtitle = "N = 2,042 U.S. Army active duty soldiers. Data from Gavin and Hofmann (2002).",
    x = NULL, y = "Count"
  ) +
  theme_minimal()

# Step one: the null model --------------------------------------------

model_null <- lmer(HOSTILE ~ 1 + (1 | COMPID), data = lq2002, REML = FALSE)

summary(model_null)

performance::icc(model_null)
ranova(model_null)

# Step two: adding a level-one predictor ------------------------------

model_1 <- lmer(HOSTILE ~ TSIG + (1 | COMPID), data = lq2002, REML = FALSE)

summary(model_1)

# Step three: a second level-one predictor ----------------------------

model_2 <- lmer(HOSTILE ~ TSIG + LEAD + (1 | COMPID), data = lq2002, REML = FALSE)

summary(model_2)

# Step four: testing an interaction -----------------------------------

model_3 <- lmer(HOSTILE ~ TSIG * LEAD + (1 | COMPID), data = lq2002, REML = FALSE)

summary(model_3)

# [fig-interaction]

library(ggeffects)

plot(ggpredict(model_3, terms = c("TSIG", "LEAD")))

anova(model_2, model_3)

# Step five: adding level-two predictors ------------------------------

model_4 <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG + (1 | COMPID), data = lq2002, REML = FALSE)

summary(model_4)

model_5 <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG + GLEAD + (1 | COMPID), data = lq2002, REML = FALSE)

summary(model_5)

# Presenting the results ----------------------------------------------

modelsummary(
  list(
    "Null"    = model_null,
    "M1"      = model_1,
    "M2"      = model_2,
    "M3: Int" = model_3,
    "M4"      = model_4,
    "M5"      = model_5
  ),
  stars = c("*" = .05, "**" = .01, "***" = .001),
  gof_map = c("nobs", "aic", "bic"),
  title = "Multilevel models predicting hostility among U.S. Army soldiers"
)

# (not run in the book - shown for reference)
# 
# modelsummary(
#   list("Null" = model_null, "M5" = model_5),
#   output = "hostility_models.docx"
# )

# What to take from this chapter --------------------------------------

