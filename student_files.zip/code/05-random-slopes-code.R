# Random Slope Models
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 05-random-slopes.qmd on 2026-08-21 - do not edit by hand.

# Reference version: complete code from the chapter.


##########################################################################
## RANDOM SLOPE MODELS
##########################################################################

# Load some packages to help with the analysis and data management ------

# [setup]

suppressPackageStartupMessages(library(tidyverse))
suppressPackageStartupMessages(library(lme4))

# Load and explore the data ---------------------------------------------

lq2002 <- read_csv("lq2002.csv")

glimpse(lq2002)

# Data management tip of the week: calculating group (cluster) means ----

lq2002.1 <- lq2002 %>%
  group_by(COMPID) %>%
  mutate(.,
            glead = mean(LEAD),
            gtsig = mean(TSIG),
            ghostile = mean(GHOSTILE)) %>%
  ungroup()

glimpse(lq2002.1)

# Do not forget `ungroup()` ---------------------------------------------

lq2002.1 %>%
  summarize(lead_check = max(abs(glead - GLEAD)),
            tsig_check = max(abs(gtsig - GTSIG)))

# Running random slopes models ------------------------------------------

## Step one: run your preferred model *without* random slopes

model.1 <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG + (1|COMPID), REML = FALSE, data = lq2002.1)

summary(model.1)

## Step two: add a random slope for TSIG

model.2 <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG + (TSIG|COMPID), REML = FALSE, data = lq2002.1)

summary(model.2)

# Reading a singular fit ------------------------------------------------

## Using `lmerTest` to evaluate random slope

lmerTest::rand(model.2)

## Step three: add a random slope for LEAD

model.3 <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG + (TSIG + LEAD|COMPID), REML = FALSE, data = lq2002.1)

summary(model.3)

## Using `lmerTest` to evaluate random slope

lmerTest::rand(model.3)

# Getting fancy: modeling a cross-level interaction ---------------------

## Step one: create centered versions of your two predictors

lq2002.2 <- lq2002.1 %>%
  mutate(.,
         tsig_cent = TSIG - mean(TSIG),
         gtsig_cent = GTSIG - mean(GTSIG))

psych::describe(lq2002.2, fast = TRUE)

## Step two: run the MLM and interpret the results

model.4 <- lmer(HOSTILE ~ tsig_cent + LEAD + gtsig_cent + (1|COMPID), REML = FALSE, data = lq2002.2)

summary(model.4)

# Interaction effects model ---------------------------------------------

model.5 <- lmer(HOSTILE ~ tsig_cent + LEAD + gtsig_cent + tsig_cent:gtsig_cent + (1|COMPID), REML = FALSE, data = lq2002.2)

summary(model.5)

# Should we include that interaction? Comparing `model.4` with `model.5` ----

anova(model.5, model.4)

# Step three: use `interplot` to obtain more easily interpretable results ----

# [fig-interplot]

interplot::interplot(model.5, var1 = "gtsig_cent", var2 = "tsig_cent")

# If `interplot` will not install ---------------------------------------

# Using `modelsummary` and `broom.mixed` to organize your results -------

library(modelsummary)
library(broom.mixed)

models <- list(model.4, model.5)

modelsummary(models, output = "markdown")

# HTML version that you can open in Word --------------------------------

# (not run in the book - shown for reference)
# 
# modelsummary(models, output = 'msum.html', title = 'MLM Estimates')

# A note on your content review -----------------------------------------

