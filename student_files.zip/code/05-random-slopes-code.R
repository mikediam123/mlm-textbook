# Random Slope and Coefficient Models
# EDUS 664 - Multilevel Modeling
# Reference version. Complete code from the chapter.
#
# Keep this file in the same folder as the data file named at the
# top of the chapter, or the read_ lines below will not find it.
# Generated from 05-random-slopes.qmd on 2026-08-15 - do not edit by hand.


##########################################################################
## RANDOM SLOPE AND COEFFICIENT MODELS
##########################################################################

# [setup]

library(tidyverse)
library(psych)
library(lme4)
library(lmerTest)
library(performance)
library(modelsummary)
library(ggeffects)

lq2002 <- read_csv("lq2002.csv")

glimpse(lq2002)

# Data management: calculating cluster means --------------------------

lq2002 <- lq2002 |>
  group_by(COMPID) |>
  mutate(
    glead    = mean(LEAD),
    gtsig    = mean(TSIG),
    ghostile = mean(HOSTILE)
  ) |>
  ungroup()

lq2002 |>
  summarize(
    lead_check = max(abs(glead - GLEAD)),
    tsig_check = max(abs(gtsig - GTSIG))
  )

# Step one: the preferred model without random slopes -----------------

model.1 <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG + (1 | COMPID),
                REML = FALSE, data = lq2002)

summary(model.1)

performance::icc(model.1)

# Step two: add a random slope for TSIG -------------------------------

model.2 <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG + (TSIG | COMPID),
                REML = FALSE, data = lq2002)

summary(model.2)

## Reading the singular fit

model.2b <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG +
                   (1 | COMPID) + (0 + TSIG | COMPID),
                 REML = FALSE, data = lq2002)

summary(model.2b)

# Evaluating the random slope -----------------------------------------

ranova(model.2)

# `rand()` became `ranova()` ------------------------------------------

# Step three: add a random slope for LEAD -----------------------------

model.3 <- lmer(HOSTILE ~ TSIG + LEAD + GTSIG + (TSIG + LEAD | COMPID),
                REML = FALSE, data = lq2002)

summary(model.3)

ranova(model.3)

# A cross-level interaction -------------------------------------------

## Center the predictors first

lq2002 <- lq2002 |>
  mutate(
    tsig_cent  = TSIG - mean(TSIG),
    gtsig_cent = GTSIG - mean(GTSIG)
  )

# Check the work: both means should be 0
psych::describe(lq2002[, c("tsig_cent", "gtsig_cent")], fast = TRUE)

## Fit and interpret

model.4 <- lmer(HOSTILE ~ tsig_cent + LEAD + gtsig_cent + (1 | COMPID),
                REML = FALSE, data = lq2002)

summary(model.4)

model.5 <- lmer(HOSTILE ~ tsig_cent + LEAD + gtsig_cent +
                  tsig_cent:gtsig_cent + (1 | COMPID),
                REML = FALSE, data = lq2002)

summary(model.5)

## Should we keep the interaction?

anova(model.4, model.5)

## Visualizing it

# [fig-crosslevel]

plot(ggpredict(model.5, terms = c("tsig_cent", "gtsig_cent [-0.5, 0, 0.5]")))

# A package change since 2020 -----------------------------------------

# Organizing the results ----------------------------------------------

models <- list(
  "Random intercept" = model.1,
  "Centered"         = model.4,
  "Interaction"      = model.5
)

modelsummary(
  models,
  stars = c("*" = .05, "**" = .01, "***" = .001),
  gof_map = c("nobs", "aic", "bic"),
  title = "Random slope and cross-level interaction models predicting hostility"
)

# (not run in the book - shown for reference)
# 
# modelsummary(models, output = "msum.docx", title = "MLM Estimates")

# A note on your content review ---------------------------------------

