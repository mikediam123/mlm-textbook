# Three-Level Models
# EDUS 664 - Multilevel Modeling
# Reference version. Complete code from the chapter.
#
# Keep this file in the same folder as the data file named at the
# top of the chapter, or the read_ lines below will not find it.
# Generated from 07-three-level.qmd on 2026-08-15 - do not edit by hand.


##########################################################################
## THREE-LEVEL MODELS
##########################################################################

# Data file needed ----------------------------------------------------

# [setup]

library(tidyverse)
library(haven)
library(lme4)
library(lmerTest)
library(performance)
library(modelsummary)

star <- read_dta("projectSTAR.dta")

glimpse(star)

# [fig-math]

ggplot(star, aes(x = gktmathss)) +
  geom_histogram(bins = 40, fill = "#1a7a6e", color = "white") +
  labs(title = "Kindergarten Math Scores",
       x = "Scale score", y = "Number of students") +
  theme_minimal()

# Specifying three levels ---------------------------------------------

m_null3 <- lmer(gktmathss ~ 1 + (1 | gkschid/gktchid), data = star, REML = FALSE)

summary(m_null3)

# (not run in the book - shown for reference)
# 
# m_null3_alt <- lmer(gktmathss ~ 1 + (1 | gkschid) + (1 | gktchid:gkschid),
#                     data = star, REML = FALSE)

# Partitioning variance across three levels ---------------------------

vc <- as.data.frame(VarCorr(m_null3))
vc

tau_class  <- vc$vcov[grepl("gktchid", vc$grp)]
tau_school <- vc$vcov[vc$grp == "gkschid"]
sigma2     <- vc$vcov[vc$grp == "Residual"]

total <- tau_class + tau_school + sigma2

round(c(
  student   = sigma2 / total,
  classroom = tau_class / total,
  school    = tau_school / total
), 3)

performance::icc(m_null3, by_group = TRUE)

# What ignoring a level costs you -------------------------------------

m_null2 <- lmer(gktmathss ~ 1 + (1 | gkschid), data = star, REML = FALSE)

vc2 <- as.data.frame(VarCorr(m_null2))
vc2

# Adding predictors at each level -------------------------------------

star <- star |>
  group_by(gkschid) |>
  mutate(sch_mean_math = mean(gktmathss, na.rm = TRUE)) |>
  ungroup() |>
  mutate(
    classtype_f = as_factor(gkclasstype),
    highdeg_f   = as_factor(gkthighdegree)
  )

m_cond3 <- lmer(
  gktmathss ~ gkselfconcraw + classtype_f + highdeg_f + sch_mean_math +
    (1 | gkschid/gktchid),
  data = star, REML = FALSE
)

summary(m_cond3)

performance::r2(m_cond3)
AIC(m_null3, m_cond3)
BIC(m_null3, m_cond3)

# About convergence warnings ------------------------------------------

# Random slopes at two levels -----------------------------------------

m_slope_class <- lmer(
  gktmathss ~ gkselfconcraw + classtype_f + highdeg_f + sch_mean_math +
    (1 | gkschid) + (1 + gkselfconcraw | gktchid:gkschid),
  data = star, REML = FALSE
)

ranova(m_slope_class)

m_slope_school <- lmer(
  gktmathss ~ gkselfconcraw + classtype_f + highdeg_f + sch_mean_math +
    (1 + gkselfconcraw | gkschid) + (1 | gktchid:gkschid),
  data = star, REML = FALSE
)

ranova(m_slope_school)

# Reporting -----------------------------------------------------------

modelsummary(
  list("Null (3-level)" = m_null3, "Conditional" = m_cond3),
  stars = c("*" = .05, "**" = .01, "***" = .001),
  gof_map = c("nobs", "aic", "bic"),
  title = "Three-level models of kindergarten math achievement"
)

