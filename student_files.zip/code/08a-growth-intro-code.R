# Intro to Growth Models
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 08a-growth-intro.qmd on 2026-08-21 - do not edit by hand.

# Reference version: complete code from the chapter.


##########################################################################
## INTRO TO GROWTH MODELS
##########################################################################

# Data file needed ------------------------------------------------------

# Load in our MVP packages ----------------------------------------------

# [setup]

suppressPackageStartupMessages(library(tidyverse))
library(lme4)

# Load in the data ------------------------------------------------------

egmerged <- haven::read_dta("egmerged.dta")

glimpse(egmerged)

# Explore the data and ID variables using `describe` from the `Hmisc` package ----

Hmisc::describe(egmerged)

# A little recoding: create factor versions of categorical variables ----

egmerged.clean <- egmerged %>%
  mutate(.,
         retained.fac = as_factor(retained),
         female.fac = as_factor(female),
         black.fac = as_factor(black),
         hispanic.fac = as_factor(hispanic),
         year0 = year - 1)

# Use `arrange` to examine variables that vary by student, year, and school ----

egmerged %>%
  arrange(., childid, year)

# Summarize math score by year, to look for preliminary changes over time ----

egmerged %>%
  group_by(year) %>%
  summarize(avg_math_score = mean(math, na.rm = TRUE)
            )

# Same thing, by grade: the only difference should be missing or retained students ----

egmerged %>%
  group_by(grade) %>%
  summarize(avg_math_score = mean(math, na.rm = TRUE)
            )

# Create summary data frame of student-level variables ------------------

student.level <-egmerged.clean %>%
  group_by(childid) %>%
  summarize(.,
            black = mean(black),
            hispanic = mean(hispanic),
            female = mean(female),
            retained = max(retained),
            math = mean(math, na.rm = TRUE))

glimpse(student.level)

# Table 1 for student-level variables -----------------------------------

library(table1)

table1(~ math + retained + black + hispanic, data = student.level)

# Create summary data frame of school-level variables -------------------

school.level <-egmerged.clean %>%
  group_by(schoolid) %>%
  summarize(.,
            lowinc = mean(lowinc),
            mobility = mean(mobility),
            size = mean(size))

glimpse(school.level)

# Table 1 for school-level variables ------------------------------------

library(table1)

table1(~ lowinc + mobility + size, data = school.level)

# Distribution of the outcome -------------------------------------------

# [fig-density]

density(egmerged.clean$math) %>%
  plot(., main = "Distribution of Math Scores")

# Getting fancy: maybe plot over time? ----------------------------------

# [fig-scatter]

scatter.smooth(x = egmerged.clean$year,
               y = egmerged.clean$math,
               main = "Distribution of Math Scores, Over Time")

# Run a regular null model for math scores ------------------------------

model.null <- lmer(math ~ (1|childid), data = egmerged.clean)

summary(model.null)

## Calculate ICC

null.icc <- 0.8483/(0.8483 + 1.5247)
null.icc

# Now, run a GROWTH null model for math scores (with year included) -----

model.null.growth <- lmer(math ~ year0 + (1|childid), data = egmerged.clean)

summary(model.null.growth)

## Calculate GROWTH ICC

null.growth.icc <- 0.8683/(0.8683 + 0.3470)
null.growth.icc

# Add a student-level predictor, female ---------------------------------

model.1 <- lmer(math ~ year0 + female + (1|childid), data = egmerged.clean)

summary(model.1)

# Add predictors for race/ethnicity: this is just for the intercept -----

model.2 <- lmer(math ~ year0 + female + black + hispanic + (1|childid), data = egmerged.clean)

summary(model.2)

# Do students differ in their growth by race/ethnicity? This is an interaction effect ----

model.3 <- lmer(math ~ year0 + female + black + hispanic + year0:black + year0:hispanic + (1|childid), data = egmerged.clean)

summary(model.3)

# Add a random slope for year at the child level ------------------------

model.4 <- lmer(math ~ year0 + female + black + hispanic +  (year0|childid), data = egmerged.clean)

summary(model.4)

# Should we keep that random slope for time? Use `rand` to test ---------

lmerTest::rand(model.4)

# Put it all together: random slope, interactions (not for Latinx students) ----

model.5 <- lmer(math ~ year0 + female + black + hispanic + year0:black + (year0|childid), data = egmerged.clean)

summary(model.5)

# Visualize our model by predicting scores ------------------------------

predicted.vals <- broom.mixed::augment(model.5, effects = c("ran_pars", "fixed"), conf.int = TRUE)

glimpse(predicted.vals)

# And then plotting them ------------------------------------------------

# [fig-predicted]

ggplot(data = predicted.vals, mapping = aes(x = year0, y = .fitted, color = as_factor(black))) +
  geom_jitter(alpha = .50) +
  geom_smooth(method = "lm", formula = 'y ~ x') +
  labs(title = "Predicted Change in Math Scores Over Time",
      subtitle = "Black Students (Teal Line) vs. All Others (Orange Line)",
      caption = "Notes. N = 1,731 students in the Sustaining Effects Study (Carter, 1984). Year 0 = Kindergarten.") +
  ylab("Predicted Math Score") +
  xlab("Year") +
  theme(legend.position = "none")

# Random slopes for a sample of 50 students -----------------------------

# [fig-fifty]

predicted.vals50 <- predicted.vals %>%
  arrange(childid, year0) %>%
  slice(., 1:252)

ggplot(data = predicted.vals50, mapping = aes(x = year0, y = .fitted, color = as_factor(childid))) +
  geom_jitter(alpha = .50) +
  geom_smooth(method = "lm", formula = 'y ~ x') +
  labs(title = "Predicted Change in Math Scores Over Time",
      caption = "Notes. N = 1,731 students in the Sustaining Effects Study (Carter, 1984). Year 0 = Kindergarten.") +
  ylab("Predicted Math Score") +
  xlab("Year") +
  theme(legend.position = "none")

# Using `modelsummary` and `broom.mixed` to organize your results -------

library(modelsummary)
library(broom.mixed)

models <- list(model.null, model.null.growth, model.1, model.2, model.3, model.4, model.5)

modelsummary(models, output = "default")

# HTML version that you can open in Word --------------------------------

# (not run in the book - shown for reference)
# 
# modelsummary(models, output = 'msum.html', title = 'MLM Estimates')

