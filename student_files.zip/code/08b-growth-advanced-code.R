# Advanced Growth Models
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 08b-growth-advanced.qmd on 2026-08-21 - do not edit by hand.

# Reference version: complete code from the chapter.


##########################################################################
## ADVANCED GROWTH MODELS
##########################################################################

# Data file needed ------------------------------------------------------

# Load in our MVP packages ----------------------------------------------

# [setup]

suppressPackageStartupMessages(library(tidyverse))
library(lme4)

# Part 1: loading in the data, reshaping from long to wide, creating new variables ----

## Load in the data

egmerged <- haven::read_dta("egmerged.dta")

glimpse(egmerged)

## Super handy trick: reshaping data

egmerged.wide <- egmerged %>%
  pivot_wider(.,
              id_cols = c("childid", "schoolid", "female", "black", "hispanic", "size", "lowinc", "mobility"),
              names_from = year,
              values_from = math,
              names_prefix = "math_year",
              )

glimpse(egmerged.wide)

egmerged.long <- egmerged.wide %>%
  pivot_longer(.,
              cols = starts_with("math"),
              names_to = "year",
              values_to = "math",
              names_prefix = "math_year",
              )

glimpse(egmerged.long)

## A little more cleanup: change `year` to numeric, drop observations with missing math scores

egmerged.long.clean <- egmerged.long %>%
  mutate(.,
         year  = as.numeric(year)) %>%
  na.omit()

glimpse(egmerged.long.clean)

## A little housekeeping: creating squared and cubic terms for time

egmerged.clean <- egmerged %>%
  mutate(.,
         retained.fac = as_factor(retained),
         female.fac = as_factor(female),
         black.fac = as_factor(black),
         hispanic.fac = as_factor(hispanic),
         year0 = year - 1,
         year_sq = year0^2,
         year_cube = year0^3)

glimpse(egmerged.clean)

# Part 2: nonlinear growth models ---------------------------------------

## Now, run a GROWTH null model for math scores (with year included)

model.null.growth <- lmer(math ~ year0 + (1|childid), data = egmerged.clean)

summary(model.null.growth)

null.growth.icc <- 0.8683/(0.8683 + 0.3470)
null.growth.icc

## Add nonlinear growth terms (square)

model.square <- lmer(math ~ year0 + year_sq + (1|childid), data = egmerged.clean)

summary(model.square)

## Add nonlinear growth terms (cubic)

model.cube <- lmer(math ~ year0 + year_cube + (1|childid), data = egmerged.clean)

summary(model.cube)

## Add nonlinear growth terms (square AND cubic)

model.both <- lmer(math ~ year0 + year_sq + year_cube + (1|childid), REML = FALSE, data = egmerged.clean)

summary(model.both)

## Should we keep that cubic term? Use `anova` to test

anova(model.square, model.both)

# Estimator matters for this comparison ---------------------------------

## Same thing, PLUS adding a random slope for year0

model.both.rand <- lmer(math ~ year0 + year_sq + year_cube + (year0|childid), REML = FALSE, data = egmerged.clean)

summary(model.both.rand)

## Should we keep that random slope for time? Use `rand` to test

lmerTest::rand(model.both.rand)

# Using `modelsummary` and `broom.mixed` to organize your results -------

library(modelsummary)
library(broom.mixed)

models1 <- list(model.null.growth, model.square, model.cube, model.both, model.both.rand)

modelsummary(models1, output = "default")

# Visualize our model by predicting scores ------------------------------

predicted.vals <- broom.mixed::augment(model.both.rand, effects = c("ran_pars", "fixed"), conf.int = TRUE)

glimpse(predicted.vals)

# And then plotting them ------------------------------------------------

# [fig-nonlinear]

ggplot(data = predicted.vals, mapping = aes(x = year0, y = .fitted)) +
  geom_jitter(alpha = .40, color = "seagreen1") +
  geom_smooth(method = "loess", formula = 'y ~ x', color = "seagreen") +
  labs(title = "Predicted Change in Math Scores Over Time",
      subtitle = "With Square and Cubic Effects for Nonlinear Growth",
      caption = "Notes. N = 1,731 students in the Sustaining Effects Study (Carter, 1984). Year 0 = Kindergarten.") +
  ylab("Predicted Math Score") +
  xlab("Year") +
  theme(legend.position = "none")

# Random slopes for a sample of 50 students -----------------------------

# [fig-fifty]

predicted.vals50 <- predicted.vals %>%
  arrange(childid, year0) %>%
  slice(., 1:252)

ggplot(data = predicted.vals50, mapping = aes(x = year0, y = .fitted, color = as_factor(childid))) +
  geom_point(alpha = .50) +
  geom_line() +
  labs(title = "Predicted Change in Math Scores Over Time",
      subtitle = "With Square and Cubic Effects for Nonlinear Growth",
      caption = "Notes. Subset of N = 50 students in the Sustaining Effects Study (Carter, 1984). Year 0 = Kindergarten.") +
  ylab("Predicted Math Score") +
  xlab("Year") +
  theme(legend.position = "none")

# Part 2: heterogeneous variance repeated measures model ----------------

library(nlme)

model.null.growth.homog <- lme(math ~ year0,
                         random = ~ year0|childid,
                         data = egmerged.clean,
                         method = "ML")

summary(model.null.growth.homog)

model.null.growth.het <- lme(math ~ year0,
                             random =  ~ year0|childid,
                             data = egmerged.clean,
                             method = "ML",
                             weights = varIdent(form = ~ 1 | year0)
)

summary(model.null.growth.het)

# Comparing across packages ---------------------------------------------

