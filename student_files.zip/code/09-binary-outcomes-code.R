# Binary and Generalized Linear Mixed Models
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 09-binary-outcomes.qmd on 2026-08-21 - do not edit by hand.

# Reference version: complete code from the chapter.


##########################################################################
## BINARY AND GENERALIZED LINEAR MIXED MODELS
##########################################################################

# Data file needed ------------------------------------------------------

# Load in our MVP packages ----------------------------------------------

# [setup]

suppressPackageStartupMessages(library(tidyverse))
library(lme4)
library(Hmisc)

# Part 1: loading in the data, and then recoding variables --------------

## Load in the data

nsch <- haven::read_dta("nsch_2018_topical.dta")

glimpse(nsch)

## The `select` function is really useful, especially with really big datasets

nsch.2 <- nsch %>%
  select(.,
         fipsst,
         hhid,
         k2q40a,
         k9q41,
         mold,
         physactiv) %>%
  as_factor()

glimpse(nsch.2)

## The `table` function is a great way to figure out how variables are labelled

table(nsch.2$k2q40a)
table(nsch.2$k9q41)
table(nsch.2$physactiv)
table(nsch.2$mold)

## Now, we can use `filter` to only keep observations that have valid categories

nsch.2.clean <- nsch.2 %>%
  filter(!(k2q40a %in%
                  c("No valid response", "Suppressed for confidentiality", "Not in universe", "Logical skip"))) %>%
  filter(!(k9q41 %in%
                  c("No valid response", "Suppressed for confidentiality", "Not in universe", "Logical skip"))) %>%
filter(!(physactiv %in%
                  c("No valid response", "Suppressed for confidentiality", "Not in universe", "Logical skip"))) %>%
filter(!(mold %in%
                  c("No valid response", "Suppressed for confidentiality", "Not in universe", "Logical skip"))) %>%
  rename(.,
        asthma = k2q40a,
        smoke_house = k9q41) %>%
  mutate(.,
         asthma.num = as.numeric(asthma),
         asthma.recode = case_when(
           asthma.num == 2 ~ 0,
           asthma.num == 1 ~ 1
         ))

glimpse(nsch.2.clean)

table(nsch.2.clean$asthma, nsch.2.clean$asthma.recode)

## The `describe` function from `Hmisc` is a nice codebook

Hmisc::describe(nsch.2.clean)

# Part 2: multilevel logistic regression models -------------------------

## We use `glmer` instead of `lmer` now that we have a binary outcome

model.null <- glmer(asthma.recode ~ (1|fipsst), family = binomial, data = nsch.2.clean)

summary(model.null)

null.icc <- 0.01808/(0.01808 + (pi^2/3))
null.icc

## Let's add a L1 predictor, whether anyone smokes in the house

model.2 <- glmer(asthma.recode ~ smoke_house + (1|fipsst), family = binomial, data = nsch.2.clean)

summary(model.2)

smoke.odds.ratio <- exp(-0.3877)
smoke.odds.ratio

# Odds are not probabilities --------------------------------------------

# Predicted probability for child in house with smoker (logit = -1.2380)

exp(-1.2380)/(1+exp(-1.2380))

# Predicted probability for child in house without smoker (logit = -1.2380 + -0.3877 = -1.6257)

exp(-1.6257)/(1+exp(-1.6257))

## Now add another L1 predictor, `mold`

model.3 <- glmer(asthma.recode ~ smoke_house + mold + (1|fipsst), family = binomial, data = nsch.2.clean)

summary(model.3)

mold.odds.ratio <- exp(-0.4672)
mold.odds.ratio

# Predicted probability for child in house with mold AND smoker (this is the intercept) (logit = -0.8724)

exp(-0.8724)/(1+exp(-0.8724))

# Predicted probability for child in house without smoker (logit = -0.8724 + -0.3590 + -0.4603 = -1.6917)

exp(-1.6917)/(1+exp(-1.6917))

## Now add a third L1 predictor, `physactiv`

model.4 <- glmer(asthma.recode ~ smoke_house + mold + physactiv + (1|fipsst), family = binomial, data = nsch.2.clean)

summary(model.4)

## How about a `mold` by `smoke_house` interaction?

model.5 <- glmer(asthma.recode ~ smoke_house + mold + smoke_house:mold + (1|fipsst), family = binomial, data = nsch.2.clean)

summary(model.5)

## Same thing, PLUS adding a random slope for `mold`

model.6 <- glmer(asthma.recode ~ smoke_house + mold + (mold|fipsst), family = binomial, data = nsch.2.clean)

summary(model.6)

## Should we keep that random slope? `rand` won't work with GLMMs, but we can compare AIC and BIC

model.6.aic <- 3045.1
model.6.bic <- 3081.8

model.5.aic <- 3042.7
model.5.bic <- 3073.2

model.6.aic - model.5.aic

model.6.bic - model.5.bic

# If `glmer` is slow or will not converge -------------------------------

# Using `modelsummary` and `broom.mixed` to organize your results -------

library(modelsummary)
library(broom.mixed)

models1 <- list(model.null, model.2, model.3, model.4, model.5, model.6)

modelsummary(models1, output = "markdown")

