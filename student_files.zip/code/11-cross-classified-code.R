# Cross-Classified Models
# EDUS 664 - Multilevel Modeling
# Reference version. Complete code from the chapter.
#
# Keep this file in the same folder as the data file named at the
# top of the chapter, or the read_ lines below will not find it.
# Generated from 11-cross-classified.qmd on 2026-08-15 - do not edit by hand.


##########################################################################
## CROSS-CLASSIFIED MODELS
##########################################################################

# Data file needed ----------------------------------------------------

# [setup]

library(tidyverse)
library(haven)
library(lme4)
library(lmerTest)
library(performance)
library(modelsummary)

scot <- read_dta("scotland.dta")

glimpse(scot)

# Confirming the structure --------------------------------------------

scot |>
  group_by(neighid) |>
  summarize(n_schools = n_distinct(schid)) |>
  count(n_schools, name = "n_neighborhoods")

# Separate null models ------------------------------------------------

m_school <- lmer(p7read ~ 1 + (1 | schid), data = scot, REML = FALSE)
m_neigh  <- lmer(p7read ~ 1 + (1 | neighid), data = scot, REML = FALSE)

summary(m_school)
summary(m_neigh)

# The combined cross-classified model ---------------------------------

m_cross <- lmer(p7read ~ 1 + (1 | schid) + (1 | neighid), data = scot, REML = FALSE)

summary(m_cross)

# Do not use the nesting shorthand here -------------------------------

vc <- as.data.frame(VarCorr(m_cross))
vc

tau_school <- vc$vcov[vc$grp == "schid"]
tau_neigh  <- vc$vcov[vc$grp == "neighid"]
sigma2     <- vc$vcov[vc$grp == "Residual"]

total <- tau_school + tau_neigh + sigma2

round(c(
  school       = tau_school / total,
  neighborhood = tau_neigh / total,
  student      = sigma2 / total
), 3)

# Why the variances shift ---------------------------------------------

# Adding predictors at each level -------------------------------------

m1 <- lmer(p7read ~ momed + daded + (1 | schid) + (1 | neighid),
           data = scot, REML = FALSE)

m2 <- lmer(p7read ~ momed + daded + dadocc + (1 | schid) + (1 | neighid),
           data = scot, REML = FALSE)

m3 <- lmer(p7read ~ momed + daded + dadocc + deprive + (1 | schid) + (1 | neighid),
           data = scot, REML = FALSE)

summary(m3)

AIC(m_cross, m1, m2, m3)
BIC(m_cross, m1, m2, m3)

# An interaction between parental education levels --------------------

m_int <- lmer(p7read ~ momed * daded + dadocc + deprive +
                (1 | schid) + (1 | neighid),
              data = scot, REML = FALSE)

summary(m_int)

# A caution about 17 schools ------------------------------------------

scot |>
  summarize(
    n_schools = n_distinct(schid),
    n_neighborhoods = n_distinct(neighid),
    n_students = n()
  )

# Reporting -----------------------------------------------------------

modelsummary(
  list("School only" = m_school, "Neighborhood only" = m_neigh,
       "Cross-classified" = m_cross, "Full model" = m3),
  stars = c("*" = .05, "**" = .01, "***" = .001),
  gof_map = c("nobs", "aic", "bic"),
  title = "Cross-classified models of Scottish primary reading attainment"
)

# Recognizing this structure elsewhere --------------------------------

