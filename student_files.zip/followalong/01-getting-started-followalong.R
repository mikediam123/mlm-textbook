# Getting Started with R and RStudio
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 01-getting-started.qmd on 2026-08-21 - do not edit by hand.

# FOLLOW-ALONG version: type the marked models yourself.


##########################################################################
## GETTING STARTED WITH R AND RSTUDIO
##########################################################################

# Data file needed ------------------------------------------------------

# Load in some useful R packages ----------------------------------------

# (not run in the book - shown for reference)
# 
# install.packages(c("tidyverse", "psych", "haven"))

library(tidyverse)
library(psych)
library(haven)

# Load in the data ------------------------------------------------------

gss <- read_dta("descriptive_gss.dta")

glimpse(gss)

# A related function you will use interactively -------------------------

# What does a variable actually contain? --------------------------------

str(gss$satjob7)

# Describe the dataset --------------------------------------------------

describe(gss, fast = TRUE)

# Create a quick histogram ----------------------------------------------

hist(gss$educ)

# Another histogram -----------------------------------------------------

hist(gss$sex, freq = FALSE)

table(gss$sex)

# Numbers that are really categories ------------------------------------

# When something breaks -------------------------------------------------

