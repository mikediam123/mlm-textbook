# Goodness-of-Fit and Effect Sizes
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 06-fit-effect-sizes.qmd on 2026-08-21 - do not edit by hand.

# FOLLOW-ALONG version: type the marked models yourself.


##########################################################################
## GOODNESS-OF-FIT AND EFFECT SIZES
##########################################################################

# Data file needed ------------------------------------------------------

library(tidyverse)
library(readr)
library(lme4)
library(lmerTest)
library(performance)
library(modelsummary)

strs <- readr::read_csv("expanded_strs_no_miss.csv") |>
  mutate(
    conflict_pre_c  = conflict_pre - mean(conflict_pre, na.rm = TRUE),
    closeness_pre_c = closeness_pre - mean(closeness_pre, na.rm = TRUE),
    treat = factor(creg23, levels = c(2, 1), labels = c("Control", "Best in Class"))
  )

# Two models to compare -------------------------------------------------

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# m_null <- lmer(conflict_post ~ 1 + (1 | strs3), data = strs, REML = FALSE)
# ------------------------------------------------------------

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# m_cond <- lmer(conflict_post ~ treat + conflict_pre_c + closeness_pre_c + (1 | strs3),
#                data = strs, REML = FALSE)
# ------------------------------------------------------------

summary(m_cond)

# Proportional reduction in variance ------------------------------------

vc_null <- as.data.frame(VarCorr(m_null))
vc_cond <- as.data.frame(VarCorr(m_cond))

tau_null   <- vc_null$vcov[vc_null$grp == "strs3"]
sigma_null <- vc_null$vcov[vc_null$grp == "Residual"]

tau_cond   <- vc_cond$vcov[vc_cond$grp == "strs3"]
sigma_cond <- vc_cond$vcov[vc_cond$grp == "Residual"]

c(tau_null = tau_null, sigma_null = sigma_null,
  tau_cond = tau_cond, sigma_cond = sigma_cond)

wg_prv <- (sigma_null - sigma_cond) / sigma_null
wg_prv

bg_prv <- (tau_null - tau_cond) / tau_null
bg_prv

total_null <- tau_null + sigma_null
total_cond <- tau_cond + sigma_cond

ml_r2 <- (total_null - total_cond) / total_null
ml_r2

## When PRV comes out negative

# The `performance` package version -------------------------------------

performance::r2(m_cond)

# Translating for a non-technical audience ------------------------------

library(ggeffects)

ggpredict(m_cond, terms = "treat")

# Model comparison with information criteria ----------------------------

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# m_slope <- lmer(conflict_post ~ treat + conflict_pre_c + closeness_pre_c +
#                   (1 + conflict_pre_c | strs3),
#                 data = strs, REML = FALSE)
# ------------------------------------------------------------

ranova(m_slope)

anova(m_cond, m_slope)

AIC(m_cond, m_slope)
BIC(m_cond, m_slope)

## When the criteria disagree

# When a model will not converge ----------------------------------------

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# m_two_slopes <- lmer(conflict_post ~ treat + conflict_pre_c + closeness_pre_c +
#                        (1 + conflict_pre_c + closeness_pre_c | strs3),
#                      data = strs, REML = FALSE)
# ------------------------------------------------------------

# (not run in the book - shown for reference)
# 
# # Uncorrelated random effects
# m_uncorr <- lmer(conflict_post ~ treat + conflict_pre_c + closeness_pre_c +
#                    (1 | strs3) + (0 + conflict_pre_c | strs3),
#                  data = strs, REML = FALSE)

# Putting it together ---------------------------------------------------

modelsummary(
  list("Null" = m_null, "Conditional" = m_cond, "+ Random slope" = m_slope),
  stars = c("*" = .05, "**" = .01, "***" = .001),
  gof_map = c("nobs", "aic", "bic"),
  title = "Models predicting end-of-year teacher-student conflict"
)

