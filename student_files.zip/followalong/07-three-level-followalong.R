# Three-Level Models
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 07-three-level.qmd on 2026-08-21 - do not edit by hand.

# FOLLOW-ALONG version: type the marked models yourself.


##########################################################################
## THREE-LEVEL MODELS
##########################################################################

# Load some packages to help with the analysis and data management ------

suppressPackageStartupMessages(library(tidyverse))
suppressPackageStartupMessages(library(lme4))

# Load and explore the data ---------------------------------------------

projectSTAR <- haven::read_dta("projectSTAR.dta")

glimpse(projectSTAR)

# Part one: data exploration and management -----------------------------

## Use `str` to figure out the 2/1 coding scheme and variable labels

str(projectSTAR)

## Create a clean dataset ready for modeling

star.clean <- projectSTAR %>%
  mutate(.,
         schoolid = gkschid,
         classid = gktchid,
         read = gktreadss,
         classtype = as_factor(gkclasstype),
         years_exp = gktyears,
         urbanicity = as_factor(gksurban),
         stu_frl = as_factor(gkfreelunch)
         ) %>%
  group_by(classid) %>% # Create a new variable, which is the average FRL by classroom:
  mutate(.,
            class_frl = mean(gkfreelunch, na.rm = TRUE) - 1
         ) %>%
  ungroup() %>%
  group_by(schoolid) %>% # Create a new variable, which is the average FRL by school:
  mutate(.,
            school_frl = mean(gkfreelunch, na.rm = TRUE) - 1
         ) %>%
  ungroup() %>%
  select(.,
         schoolid,
         classid,
         read,
         classtype,
         years_exp,
         urbanicity,
         stu_frl,
         class_frl,
         school_frl)

glimpse(star.clean)

# Why the `- 1` trick works, and when it does not -----------------------

# Part two: the null 3-level model --------------------------------------

## Run a null 3-level model for reading scores

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.0 <- lmer(read ~ (1|schoolid) + (1|classid), data = star.clean)
# ------------------------------------------------------------

summary(model.0)

# Why this syntax works here --------------------------------------------

## Calculate L2 ICC (classroom)

ICC.class <- 114.9/(728.2 + 169.8 + 114.9)
ICC.class

## Calculate L3 ICC (school)

ICC.school <- 169.8/(728.2 + 169.8 + 114.9)
ICC.school

# Part three: add predictors at each level ------------------------------

## Add a student-level predictor, FRL

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.1 <- lmer(read ~ stu_frl + (1|schoolid) + (1|classid), data = star.clean)
# ------------------------------------------------------------

summary(model.1)

## Add teacher-level predictors: years of experience and class type

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.2 <- lmer(read ~ stu_frl + years_exp + classtype + (1|schoolid) + (1|classid), data = star.clean)
# ------------------------------------------------------------

summary(model.2)

## Add a school-level predictor, urbanicity of school

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.3 <- lmer(read ~ stu_frl + years_exp + classtype + urbanicity + (1|schoolid) + (1|classid), data = star.clean)
# ------------------------------------------------------------

summary(model.3)

## Add in FRL at all three levels (student, teacher, school)

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.4 <- lmer(read ~ stu_frl +  class_frl + school_frl +  years_exp + classtype + urbanicity + (1|schoolid) + (1|classid), data = star.clean)
# ------------------------------------------------------------

summary(model.4)

# Part four: try adding a random slope ----------------------------------

## Add a random slope for years of experience at level 3 (school)

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.5 <- lmer(read ~ stu_frl + years_exp + classtype + urbanicity + (1|classid) + (years_exp|schoolid), data = star.clean)
# ------------------------------------------------------------

summary(model.5)

# Should we include that random slope? Comparing `model.4` with `model.5` ----

anova(model.4, model.5)

# These two models differ in more than the random slope -----------------

# Using `modelsummary` and `broom.mixed` to organize your results -------

library(modelsummary)
library(broom.mixed)

models <- list(model.0, model.1, model.2, model.3, model.4, model.5)

modelsummary(models, output = "default")

# HTML version that you can open in Word --------------------------------

# (not run in the book - shown for reference)
# 
# modelsummary(models, output = 'msum.html', title = 'MLM Estimates')

