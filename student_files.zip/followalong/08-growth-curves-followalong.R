# Longitudinal and Growth Curve Models
# EDUS 664 - Multilevel Modeling
# FOLLOW-ALONG version. Type the marked models yourself.
#
# Keep this file in the same folder as the data file named at the
# top of the chapter, or the read_ lines below will not find it.
# Generated from 08-growth-curves.qmd on 2026-08-15 - do not edit by hand.


##########################################################################
## LONGITUDINAL AND GROWTH CURVE MODELS
##########################################################################

# Data files needed ---------------------------------------------------

# [setup]

library(tidyverse)
library(haven)
library(lme4)
library(lmerTest)
library(performance)
library(modelsummary)
library(ggeffects)

star_long <- read_dta("STAR_long.dta")

glimpse(star_long)

# Coding time ---------------------------------------------------------

star_long <- star_long |>
  mutate(grade_0 = grade - 3)

# Looking at trajectories first ---------------------------------------

# [fig-spaghetti]

set.seed(664)
all_ids <- unique(star_long$stdntid)
sampled_ids <- sample(all_ids, min(30, length(all_ids)))

star_long |>
  filter(stdntid %in% sampled_ids) |>
  ggplot(aes(x = grade_0, y = science, group = stdntid)) +
  geom_line(alpha = 0.35) +
  geom_smooth(aes(group = NULL), method = "loess", color = "#1a7a6e", linewidth = 1.2) +
  labs(title = "Science Score Trajectories",
       subtitle = "30 randomly selected students",
       x = "Grades since 3rd", y = "Science score") +
  theme_minimal()

# Null model versus null growth model ---------------------------------

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_null <- lmer(science ~ 1 + (1 | stdntid), data = star_long, REML = FALSE)
# -------------------------------------------------------------


summary(m_null)

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_growth_null <- lmer(science ~ grade_0 + (1 | stdntid), data = star_long, REML = FALSE)
# -------------------------------------------------------------


summary(m_growth_null)

# A conditional growth model ------------------------------------------

star_long <- star_long |>
  mutate(
    gender_f = as_factor(gender),
    race_f   = as_factor(race)
  )

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_cond <- lmer(science ~ grade_0 + gender_f + race_f + ac_mot + (1 | stdntid),
#                data = star_long, REML = FALSE)
# -------------------------------------------------------------


summary(m_cond)

# Does motivation predict growth? -------------------------------------

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_interact <- lmer(science ~ grade_0 * ac_mot + gender_f + race_f + (1 | stdntid),
#                    data = star_long, REML = FALSE)
# -------------------------------------------------------------


summary(m_interact)

# [fig-motivation]

plot(ggpredict(m_interact, terms = c("grade_0", "ac_mot")))

# A random slope for time ---------------------------------------------

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_rs <- lmer(science ~ grade_0 * ac_mot + gender_f + race_f +
#                (1 + grade_0 | stdntid),
#              data = star_long, REML = FALSE)
# -------------------------------------------------------------


summary(m_rs)

ranova(m_rs)

# Nonlinear growth ----------------------------------------------------

star_wide <- read_dta("STAR_wide.dta")

star_clean <- star_wide |>
  pivot_longer(
    cols = starts_with("science"),
    names_to = "grade",
    values_to = "science",
    names_prefix = "science"
  ) |>
  mutate(
    grade = as.numeric(grade),
    grade0 = grade - 3,
    grade0_sq = grade0^2,
    grade0_cub = grade0^3
  )

glimpse(star_clean)

star_clean |>
  count(stdntid) |>
  count(n, name = "n_students")

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_lin  <- lmer(science ~ grade0 + (1 | stdntid), data = star_clean, REML = FALSE)
# -------------------------------------------------------------

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_quad <- lmer(science ~ grade0 + grade0_sq + (1 | stdntid), data = star_clean, REML = FALSE)
# -------------------------------------------------------------

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_cub  <- lmer(science ~ grade0 + grade0_sq + grade0_cub + (1 | stdntid), data = star_clean, REML = FALSE)
# -------------------------------------------------------------


anova(m_lin, m_quad, m_cub)

AIC(m_lin, m_quad, m_cub)
BIC(m_lin, m_quad, m_cub)

# Heterogeneous variance structures -----------------------------------

library(nlme)

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_homog <- lme(science ~ grade0 + grade0_sq,
#                random = ~ 1 | stdntid,
#                data = star_clean, method = "ML",
#                na.action = na.omit)
# -------------------------------------------------------------


# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_heterog <- lme(science ~ grade0 + grade0_sq,
#                  random = ~ 1 | stdntid,
#                  weights = varIdent(form = ~ 1 | grade0),
#                  data = star_clean, method = "ML",
#                  na.action = na.omit)
# -------------------------------------------------------------


anova(m_homog, m_heterog)

summary(m_heterog)$modelStruct$varStruct

# Two packages, two conventions ---------------------------------------

