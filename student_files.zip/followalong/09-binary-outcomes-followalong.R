# Generalized Multilevel Models for Binary Outcomes
# EDUS 664 - Multilevel Modeling
# FOLLOW-ALONG version. Type the marked models yourself.
#
# Keep this file in the same folder as the data file named at the
# top of the chapter, or the read_ lines below will not find it.
# Generated from 09-binary-outcomes.qmd on 2026-08-15 - do not edit by hand.


##########################################################################
## GENERALIZED MULTILEVEL MODELS FOR BINARY OUTCOMES
##########################################################################

# Data file needed ----------------------------------------------------

# [setup]

library(tidyverse)
library(lme4)
library(performance)
library(modelsummary)
library(ggeffects)

belong <- read_csv("school_belonging.csv")

glimpse(belong)

belong |>
  count(school_belonging) |>
  mutate(proportion = n / sum(n))

# The null model ------------------------------------------------------

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_null <- glmer(school_belonging ~ 1 + (1 | school_id),
#                 family = binomial(link = "logit"),
#                 data = belong)
# -------------------------------------------------------------


summary(m_null)

# The ICC, with a wrinkle ---------------------------------------------

vc <- as.data.frame(VarCorr(m_null))
tau00 <- vc$vcov[vc$grp == "school_id"]

icc_logistic <- tau00 / (tau00 + (pi^2 / 3))
icc_logistic

performance::icc(m_null)

# Student-level predictors --------------------------------------------

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_l1 <- glmer(school_belonging ~ peer_inclusivity + teacher_support +
#                 community_activities + (1 | school_id),
#               family = binomial(link = "logit"),
#               data = belong)
# -------------------------------------------------------------


summary(m_l1)

exp(fixef(m_l1))

exp(confint(m_l1, method = "Wald"))

## Saying it correctly

# A school-level predictor --------------------------------------------

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_l2 <- glmer(school_belonging ~ peer_inclusivity + teacher_support +
#                 community_activities + small_school + (1 | school_id),
#               family = binomial(link = "logit"),
#               data = belong)
# -------------------------------------------------------------


summary(m_l2)
exp(fixef(m_l2))

# Predicted probabilities ---------------------------------------------

ggpredict(m_l2, terms = c("peer_inclusivity", "teacher_support"))

# [fig-probs]

plot(ggpredict(m_l2, terms = c("peer_inclusivity", "teacher_support")))

# A student with all supports, in a small school
profile_high <- data.frame(
  peer_inclusivity = 1, teacher_support = 1,
  community_activities = 1, small_school = 1, school_id = NA
)

# A student with none, in a large school
profile_low <- data.frame(
  peer_inclusivity = 0, teacher_support = 0,
  community_activities = 0, small_school = 0, school_id = NA
)

predict(m_l2, newdata = profile_high, type = "response", re.form = NA)
predict(m_l2, newdata = profile_low,  type = "response", re.form = NA)

# Reporting -----------------------------------------------------------

modelsummary(
  list("Null" = m_null, "Student level" = m_l1, "+ School size" = m_l2),
  exponentiate = TRUE,
  stars = c("*" = .05, "**" = .01, "***" = .001),
  gof_map = c("nobs", "aic", "bic"),
  title = "Multilevel logistic models predicting strong school belonging (odds ratios)"
)

# If the model runs slowly or will not converge -----------------------

