# Assessing Assumptions
# EDUS 664 - Multilevel Modeling
# FOLLOW-ALONG version. Type the marked models yourself.
#
# Keep this file in the same folder as the data file named at the
# top of the chapter, or the read_ lines below will not find it.
# Generated from 10-assumptions.qmd on 2026-08-15 - do not edit by hand.


##########################################################################
## ASSESSING ASSUMPTIONS
##########################################################################

# Data file needed ----------------------------------------------------

# [setup]

library(tidyverse)
library(haven)
library(lme4)
library(lmerTest)
library(broom.mixed)
library(performance)
library(modelsummary)

star <- read_dta("projectSTAR.dta") |>
  mutate(
    classtype_f = as_factor(gkclasstype),
    highdeg_f   = as_factor(gkthighdegree)
  )

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m <- lmer(gktmathss ~ gkselfconcraw + classtype_f + highdeg_f + (1 | gktchid),
#           data = star, REML = FALSE)
# -------------------------------------------------------------


summary(m)

# Extracting residuals and fitted values ------------------------------

aug <- augment(m)

glimpse(aug)

aug <- aug |>
  mutate(std_resid = as.numeric(scale(.resid)))

# Normality of residuals ----------------------------------------------

# [fig-resid-hist]

ggplot(aug, aes(x = std_resid)) +
  geom_histogram(bins = 40, fill = "#1a7a6e", color = "white") +
  labs(title = "Standardized Residuals", x = "Standardized residual", y = "Count") +
  theme_minimal()

# [fig-qq]

ggplot(aug, aes(sample = std_resid)) +
  stat_qq(alpha = 0.3, color = "#1a7a6e") +
  stat_qq_line(color = "#b2182b") +
  labs(title = "Normal Q-Q Plot", x = "Theoretical quantiles", y = "Sample quantiles") +
  theme_minimal()

## How many observations are we actually working with?

nrow(star)      # rows in the dataset
nrow(aug)       # rows the model actually used

## A formal test, with a caveat

# Shapiro-Wilk accepts between 3 and 5,000 observations, so sample if needed
if (nrow(aug) > 5000) {
  set.seed(664)
  shapiro.test(sample(aug$std_resid, 5000))
} else {
  shapiro.test(aug$std_resid)
}

# Linearity and constant variance -------------------------------------

# [fig-rvf]

ggplot(aug, aes(x = .fitted, y = .resid)) +
  geom_point(alpha = 0.2, size = 0.7, color = "#1a7a6e") +
  geom_hline(yintercept = 0, color = "gray40") +
  geom_smooth(method = "loess", color = "#b2182b", se = FALSE) +
  labs(title = "Residuals vs. Fitted Values",
       x = "Fitted value", y = "Residual") +
  theme_minimal()

# [fig-checkmodel]

check_model(m)

# Influential cases ---------------------------------------------------

library(influence.ME)

# Influence at the observation level can be slow on large datasets.
# Estimating influence by cluster is usually more informative anyway.
infl <- influence(m, group = "gktchid")

cooks <- cooks.distance(infl)

# influence.ME returns a matrix, with the classroom labels in the ROWNAMES,
# not in names(). Check what you actually got before building a data frame.
str(cooks)

grp_labels <- rownames(cooks)
if (is.null(grp_labels)) grp_labels <- names(cooks)
if (is.null(grp_labels)) grp_labels <- as.character(seq_len(length(cooks)))

cook_df <- tibble(
  gktchid = grp_labels,
  cooks_d = as.numeric(cooks)
)

cook_df |> arrange(desc(cooks_d)) |> head(10)

# A silent failure worth knowing about --------------------------------

# [fig-cooks]

cutoff <- 4 / nrow(cook_df)

ggplot(cook_df, aes(x = seq_along(cooks_d), y = cooks_d)) +
  geom_point(alpha = 0.6, color = "#1a7a6e") +
  geom_hline(yintercept = cutoff, linetype = "dashed", color = "#b2182b") +
  labs(title = "Cook's Distance by Classroom",
       subtitle = paste0("Dashed line at 4/n = ", round(cutoff, 4)),
       x = "Classroom index", y = "Cook's distance") +
  theme_minimal()

# The part that settles it: robustness checks -------------------------

library(clubSandwich)

# Cluster-robust standard errors.
# clubSandwich reads the clustering structure from the fitted model,
# so we do not pass a cluster vector ourselves. See the note below.
robust_test <- coef_test(m, vcov = "CR2")
robust_test

# Do not pass `cluster = star$gktchid` here ---------------------------

# The model with the most influential clusters removed
flagged <- cook_df |> filter(cooks_d > cutoff) |> pull(gktchid)

length(flagged)   # how many classrooms are we dropping?

# Compare as character on both sides. The labels came out of rownames(),
# so they are character, while gktchid in the data is numeric.
star_trimmed <- star |> filter(!(as.character(gktchid) %in% flagged))

nrow(star); nrow(star_trimmed)

# ---- YOUR TURN ----------------------------------------------
# Type the model here while the video walks through it.
# The version from the book is commented out below; uncomment
# it only after you have written your own and compared.

# m_trimmed <- lmer(gktmathss ~ gkselfconcraw + classtype_f + highdeg_f + (1 | gktchid),
#                   data = star_trimmed, REML = FALSE)
# -------------------------------------------------------------


summary(m_trimmed)

modelsummary(
  list("Original" = m, "Outliers removed" = m_trimmed),
  stars = c("*" = .05, "**" = .01, "***" = .001),
  gof_map = c("nobs", "aic", "bic"),
  title = "Robustness of the class type estimate to influential clusters"
)

# Writing it up -------------------------------------------------------

