# Checking Assumptions for MLMs
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 10-assumptions.qmd on 2026-08-21 - do not edit by hand.

# FOLLOW-ALONG version: type the marked models yourself.


##########################################################################
## CHECKING ASSUMPTIONS FOR MLMS
##########################################################################

# Data file needed ------------------------------------------------------

# Load in our MVP packages ----------------------------------------------

suppressPackageStartupMessages(library(tidyverse))
library(lme4)
library(Hmisc)

# Part 1: loading in the data, and then recoding variables --------------

## Load in the data

productivity <- haven::read_dta("productivity.dta")

glimpse(productivity)

## The `describe` function from `Hmisc` is a nice codebook

Hmisc::describe(productivity)

# A little quick cleaning -----------------------------------------------

prod.clean <- productivity %>%
  mutate(.,
         region.fac = as_factor(region),
         year0 = year - 1970,
         year_sq = year0^2,
         year_cube = year0^3,
         pub_cap_1000 = public/1000)

glimpse(prod.clean)

# Part 2: find your "final" or preferred model --------------------------

## Start with a null growth model since this is longitudinal data

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.null.growth <- lmer(unemp ~ year0 + (1|state), REML = FALSE, data = prod.clean)
# ------------------------------------------------------------

summary(model.null.growth)

## Add in quadratic effects

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.2 <- lmer(unemp ~ year0 + year_sq + (1|state), REML = FALSE, data = prod.clean)
# ------------------------------------------------------------

summary(model.2)

## Add in cubic effects

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.3 <- lmer(unemp ~ year0 + year_cube + (1|state), REML = FALSE, data = prod.clean)
# ------------------------------------------------------------

summary(model.3)

## Both quadratic and cubic effects

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.4 <- lmer(unemp ~ year0 + year_sq + year_cube + (1|state), REML = FALSE, data = prod.clean)
# ------------------------------------------------------------

summary(model.4)

## Now for some more predictors

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.5 <- lmer(unemp ~ year0 + year_sq + year_cube + gsp + private + pub_cap_1000 + (1|state), REML = FALSE, data = prod.clean)
# ------------------------------------------------------------

summary(model.5)

# Use the `augment` function from the `broom.mixed` package -------------

library(broom.mixed)

diagnostics <- augment(model.5)

# Step 1: assess normality of residuals ---------------------------------

## Visually, with a histogram

ggplot(data = diagnostics, mapping = aes(x = .resid)) +
  geom_histogram(binwidth = .25) + theme_classic() +
  labs(title = "Histogram of Residuals for State Unemployment Model",
                      x = "Residual Value") +
  geom_vline(xintercept = c(-2.5, 2.5), linetype = "dotted")

## Statistically, with the Shapiro-Wilk test

shapiro.test(diagnostics$.resid)

# A size limit on this test ---------------------------------------------

# Step 2: use a residuals vs. fitted (RVF) plot to assess homoskedasticity of errors ----

## Basic RVF plot, without groups

ggplot(data = diagnostics, mapping = aes(x = .fitted, y = .resid)) +
  geom_point() + labs(title = "RVF Plot for State Unemployment Model",
                      x = "Predicted Value, % Unemployment",
                      y = "Residual Value") + theme_classic()

## Same thing, but with added color by year0

ggplot(data = diagnostics, mapping = aes(x = .fitted, y = .resid, color = year0)) +
  geom_point() + labs(title = "RVF Plot for State Unemployment Model, by Year",
                      x = "Predicted Value, % Unemployment",
                      y = "Residual Value") + theme_classic()

# Step 3: use Cook's distance to identify outliers ----------------------

ggplot(data = diagnostics, mapping = aes(x = .fitted, y = .cooksd, label = state)) +
  geom_point() + geom_text(nudge_x = .25) + theme_classic() +
  labs(title = "Cook's Distance Plot for State Unemployment Model",
                      x = "Predicted Value, % Unemployment",
                      y = "Cook's Distance") +
  geom_hline(yintercept = 4/816, linetype = "dotted")

# Step 4: re-run model with robust standard errors ----------------------

library(robustlmm)

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.robust <- rlmer(unemp ~ year0 + year_sq + year_cube + gsp + private + pub_cap_1000 + (1|state), REML = FALSE, data = prod.clean)
# ------------------------------------------------------------

summary(model.robust)

# Step 5: re-run model with outliers removed (Cook's distance > .10) ----

prod.trimmed <- diagnostics %>%
  filter(., .cooksd < .10)

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.trimmed <- lmer(unemp ~ year0 + year_sq + year_cube + gsp + private + pub_cap_1000 + (1|state), REML = FALSE, data = prod.trimmed)
# ------------------------------------------------------------

summary(model.trimmed)

nrow(diagnostics); nrow(prod.trimmed)

# Step 6: compare original "final" model, robust model, and trimmed model ----

library(modelsummary)

models <- list(model.5, model.trimmed)

modelsummary(models, output = "markdown")

# Writing it up ---------------------------------------------------------

