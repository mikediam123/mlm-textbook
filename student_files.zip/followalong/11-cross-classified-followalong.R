# Cross-Classified Linear Mixed Models
# EDUS 664 - Multilevel Modeling
#
# Keep this file in the same folder as the data file named at the top of
# the chapter, or the read_ lines below will not find it.
# Generated from 11-cross-classified.qmd on 2026-08-21 - do not edit by hand.

# FOLLOW-ALONG version: type the marked models yourself.


##########################################################################
## CROSS-CLASSIFIED LINEAR MIXED MODELS
##########################################################################

# Load in our MVP packages ----------------------------------------------

suppressPackageStartupMessages(library(tidyverse))
library(lme4)
library(Hmisc)

# Part 1: loading in the data, and then recoding variables --------------

## Load in the data

scotland <- haven::read_dta("scotland.dta")

glimpse(scotland)

## The `describe` function from `Hmisc` is a great codebook

describe(scotland)

# Part one: data exploration and coding/labelling -----------------------

## Start with variable labelling using the `label` function

label(scotland$neighid)="Neighborhood ID"
label(scotland$schid)="School ID"
label(scotland$attain)="Student Measure of Educational Attainment"
label(scotland$p7vrq)="Primary 7 Verbal Reasoning Quotient"
label(scotland$p7read)="Primary 7 Reading Test Scores"
label(scotland$dadocc)="School Mean of Dad's Occupation Score on Hope-Goldthorpe Scale"
label(scotland$dadunemp)="Dad Currently Unemployed"
label(scotland$daded)="Dad School After Age 15"
label(scotland$momed)="Mom School After Age 15"
label(scotland$male)="Male"
label(scotland$deprive)="Neighborhood Deprivation Score (Poverty, Health, and Housing)"

scot.clean <- scotland %>%
  mutate(.,
         dadunemp.fac = as_factor(dadunemp),
         daded.fac = as_factor(daded),
         momed.fac = as_factor(momed),
         male.fac = as_factor(male))

levels(scot.clean$dadunemp.fac) = c("No","Yes")
levels(scot.clean$daded.fac) = c("No","Yes")
levels(scot.clean$momed.fac) = c("No","Yes")
levels(scot.clean$male.fac) = c("No","Yes")

glimpse(scot.clean)

describe(scot.clean)

## Explore our outcome, `attain`

ggplot(data = scot.clean, mapping = aes(x = attain)) +
  geom_histogram(bins = 20) +
  labs(title = "Distribution of Educational Attainment Scores",
       x = "Standardized Educational Attainment Score") +
  theme_minimal()

## Explore a few other predictors

ggplot(data = scot.clean, mapping = aes(x = dadocc)) +
  geom_histogram(bins = 30) +
  labs(title = "Distribution of (School Mean) of Dad's Occupation Scores",
       x = "Standardized Educational Attainment Score") +
  theme_minimal()

ggplot(data = scot.clean, mapping = aes(x = deprive)) +
  geom_histogram(bins = 50) +
  labs(title = "Distribution of Neighborhood Context Scores",
       x = "Standardized Neighborhood Deprivation Score") +
  theme_minimal()

# Part two: modeling ----------------------------------------------------

## First, run two separate models with school and neighborhood as the L2 clusters

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.null.school <- lmer(attain ~ (1|schid), REML = FALSE, data = scot.clean)
# ------------------------------------------------------------

summary(model.null.school)

## Calculate school ICC

icc.school <- 0.08874/(0.08874 + 0.93441)
icc.school

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.null.neigh <- lmer(attain ~ (1|neighid), REML = FALSE, data = scot.clean)
# ------------------------------------------------------------

summary(model.null.neigh)

## Calculate neighborhood ICC

icc.neigh <- 0.2015/(0.2015 + 0.8044)
icc.neigh

## Now, a null additive cross-classified model

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.null.crossed <- lmer(attain ~ (1|schid) + (1|neighid), REML = FALSE, data = scot.clean)
# ------------------------------------------------------------

summary(model.null.crossed)

# Do not use the nesting shorthand here ---------------------------------

## Calculate neighborhood ICC in crossed model

icc.neigh.crossed <- 0.14122/(0.14122 + 0.07545 + 0.79902)
icc.neigh.crossed

## Calculate school ICC in crossed model

icc.school.crossed <- 0.07545/(0.14122 + 0.07545 + 0.79902)
icc.school.crossed

## Add an L1 predictor, male

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.1 <- lmer(attain ~ male.fac + (1|schid) + (1|neighid), REML = FALSE, data = scot.clean)
# ------------------------------------------------------------

summary(model.1)

## L1 plus school-level predictor only (`dadocc`)

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.2 <- lmer(attain ~ male.fac + dadocc + (1|schid) + (1|neighid), REML = FALSE, data = scot.clean)
# ------------------------------------------------------------

summary(model.2)

## L1 plus neighborhood-level predictors only (`deprive`)

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.3 <- lmer(attain ~ male.fac + deprive + (1|schid) + (1|neighid), REML = FALSE, data = scot.clean)
# ------------------------------------------------------------

summary(model.3)

## L1 plus both school and neighborhood predictors

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.4 <- lmer(attain ~ male.fac + deprive + dadocc + (1|schid) + (1|neighid), REML = FALSE, data = scot.clean)
# ------------------------------------------------------------

summary(model.4)

## Test random effects for `male.fac` at neighborhood level and at school level

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.5 <- lmer(attain ~ male.fac + deprive + dadocc + (male.fac|schid) + (male.fac|neighid), REML = FALSE, data = scot.clean)
# ------------------------------------------------------------

summary(model.5)

lmerTest::rand(model.5)

## Finally, test a model with school-neighborhood interaction

# ---- YOUR TURN ---------------------------------------------
# Type the model here while the video walks through it.

# The book's version, for checking after you have tried:
# model.6 <- lmer(attain ~ male.fac + deprive + dadocc + deprive:dadocc + (1|schid) + (1|neighid), REML = FALSE, data = scot.clean)
# ------------------------------------------------------------

summary(model.6)

## Use `interplot` to visualize the interaction between `deprive` and `dadocc`

interplot::interplot(model.6, var1 = "deprive", var2 = "dadocc")

# If `interplot` will not install ---------------------------------------

# Comparing the models --------------------------------------------------

library(modelsummary)
library(broom.mixed)

models <- list(model.null.neigh, model.null.school, model.null.crossed, model.1, model.2, model.3, model.4, model.5, model.6)

modelsummary(models, output = "markdown")

# A caution about 17 schools --------------------------------------------

# Recognizing this structure elsewhere ----------------------------------

